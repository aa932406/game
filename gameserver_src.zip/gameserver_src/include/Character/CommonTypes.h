// CommonTypes.h
#ifndef COMMONTYPES_H
#define COMMONTYPES_H

#include <cstdint>
#include <string>
#include <list>
#include <vector>
#include <map>

typedef int64_t CharId_t;
typedef int64_t EquipId_t;
typedef int64_t FamilyId_t;
typedef int64_t EntityId_t;
typedef int32_t Time_t;
typedef int32_t ItemId_t;
typedef int32_t ProcId_t;
typedef int32_t GateIndex_t;
typedef int8_t ConnId_t;
typedef int32_t Job_t;
typedef int8_t Sex_t;
typedef int8_t Direction;
typedef int32_t ServerId_t;

#endif