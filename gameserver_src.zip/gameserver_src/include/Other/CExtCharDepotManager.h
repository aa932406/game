#include "../Character/CExtCharDepotManager.h"
