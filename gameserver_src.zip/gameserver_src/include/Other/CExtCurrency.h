#include "../Character/CExtCurrency.h"
