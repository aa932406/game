#include "../Character/CExtMagicBox.h"
