#include "../Character/CExtCharTencent.h"
