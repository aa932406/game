#include "../Character/CExtFightChecker.h"
