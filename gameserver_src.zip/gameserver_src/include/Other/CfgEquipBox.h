#include "../Config/CfgEquipBox.h"
