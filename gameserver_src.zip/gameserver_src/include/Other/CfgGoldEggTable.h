#include "../Config/CfgGoldEggTable.h"
