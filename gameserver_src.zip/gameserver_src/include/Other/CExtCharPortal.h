#include "../Character/CExtCharPortal.h"
