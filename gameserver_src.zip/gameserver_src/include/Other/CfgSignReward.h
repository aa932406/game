#include "../Config/CfgSignReward.h"
