#include "../Config/CfgEquipTable.h"
