#include "../Config/CfgNpc.h"
