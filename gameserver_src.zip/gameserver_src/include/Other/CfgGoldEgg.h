#include "../Config/CfgGoldEgg.h"
