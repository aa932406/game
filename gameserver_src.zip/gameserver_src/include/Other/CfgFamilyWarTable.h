#include "../Config/CfgFamilyWarTable.h"
