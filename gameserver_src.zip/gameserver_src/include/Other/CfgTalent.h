#include "../Config/CfgTalent.h"
