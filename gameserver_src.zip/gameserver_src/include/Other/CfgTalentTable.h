#include "../Config/CfgTalentTable.h"
