#include "../Character/CExtCharWish.h"
