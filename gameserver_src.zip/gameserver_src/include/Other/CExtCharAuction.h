#include "../Character/CExtCharAuction.h"
