#include "../Character/CExtCharDepot.h"
