#include "../Config/CfgEquipUpStar.h"
