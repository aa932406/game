#include "../Config/CfgTouZiTable.h"
