#include "../Config/CfgEquipBoxTable.h"
