#include "../Character/CExtCharBag.h"
