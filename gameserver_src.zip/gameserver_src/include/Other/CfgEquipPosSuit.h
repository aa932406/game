#include "../Config/CfgEquipPosSuit.h"
