#ifndef __PLANT_ACTIVITY_H__
#define __PLANT_ACTIVITY_H__

#include "Game/Plant.h"
#include <cstdint>

class CActivityMap;
class Player;
class CfgPlant;
class CfgMapPlant;

class PlantActivity : public Plant
{
public:
    PlantActivity();
    virtual ~PlantActivity();

    // 初始化
    void init(CActivityMap* pActivityMap,
              const CfgPlant* const cfgPlant,
              const CfgMapPlant* const cfgMapPlant,
              int32_t nLifeTime);
    
    // 采集
    virtual int32_t onBeginGather(Player* player) override;
    virtual void onEndGather(Player* player) override;
    
    // 生命周期
    bool IsExpired() const;
    int32_t GetLeftTime() const;
    void SetLifeTime(int32_t lifeTime);
    
    // 定时器
    virtual void OnTimer(int64_t curTick) override;
    
    // Getter
    CActivityMap* GetActivityMap() const;

protected:
    CActivityMap* m_pActivityMap;
    int32_t m_nLifeTime;
};

#endif // __PLANT_ACTIVITY_H__