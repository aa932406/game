#include \"../Config/CfgMapMonster.h\"
